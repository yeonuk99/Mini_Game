﻿namespace Moble
{
    partial class Plus
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lb_Score = new System.Windows.Forms.Label();
            timer1 = new System.Windows.Forms.Timer(components);
            label2 = new System.Windows.Forms.Label();
            btn_Number_0 = new System.Windows.Forms.Button();
            btn_Number_1 = new System.Windows.Forms.Button();
            btn_Number_2 = new System.Windows.Forms.Button();
            btn_Number_3 = new System.Windows.Forms.Button();
            btn_Number_4 = new System.Windows.Forms.Button();
            btn_Number_9 = new System.Windows.Forms.Button();
            btn_Number_8 = new System.Windows.Forms.Button();
            btn_Number_7 = new System.Windows.Forms.Button();
            btn_Number_6 = new System.Windows.Forms.Button();
            btn_Number_5 = new System.Windows.Forms.Button();
            btn_Equal = new System.Windows.Forms.Button();
            label3 = new System.Windows.Forms.Label();
            lb_x = new System.Windows.Forms.Label();
            lb_y = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            labelProgressBar1 = new LabelProgressBar();
            timer2 = new System.Windows.Forms.Timer(components);
            lb_Sec = new System.Windows.Forms.Label();
            btn_Plus_ok = new System.Windows.Forms.Button();
            lb_Plus_lastscore = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // lb_Score
            // 
            lb_Score.AutoSize = true;
            lb_Score.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Score.ForeColor = System.Drawing.Color.White;
            lb_Score.Location = new System.Drawing.Point(175, 35);
            lb_Score.Name = "lb_Score";
            lb_Score.Size = new System.Drawing.Size(146, 74);
            lb_Score.TabIndex = 0;
            lb_Score.Text = "200";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.Color.White;
            label2.Location = new System.Drawing.Point(225, 100);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(52, 19);
            label2.TabIndex = 2;
            label2.Text = "score";
            // 
            // btn_Number_0
            // 
            btn_Number_0.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_0.Location = new System.Drawing.Point(12, 434);
            btn_Number_0.Name = "btn_Number_0";
            btn_Number_0.Size = new System.Drawing.Size(87, 83);
            btn_Number_0.TabIndex = 3;
            btn_Number_0.Text = "button1";
            btn_Number_0.UseVisualStyleBackColor = true;
            btn_Number_0.Click += btn_Number_0_Click;
            // 
            // btn_Number_1
            // 
            btn_Number_1.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_1.Location = new System.Drawing.Point(105, 434);
            btn_Number_1.Name = "btn_Number_1";
            btn_Number_1.Size = new System.Drawing.Size(87, 83);
            btn_Number_1.TabIndex = 4;
            btn_Number_1.Text = "button2";
            btn_Number_1.UseVisualStyleBackColor = true;
            btn_Number_1.Click += btn_Number_1_Click;
            // 
            // btn_Number_2
            // 
            btn_Number_2.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_2.Location = new System.Drawing.Point(198, 434);
            btn_Number_2.Name = "btn_Number_2";
            btn_Number_2.Size = new System.Drawing.Size(87, 83);
            btn_Number_2.TabIndex = 5;
            btn_Number_2.Text = "button3";
            btn_Number_2.UseVisualStyleBackColor = true;
            btn_Number_2.Click += btn_Number_2_Click;
            // 
            // btn_Number_3
            // 
            btn_Number_3.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_3.Location = new System.Drawing.Point(291, 434);
            btn_Number_3.Name = "btn_Number_3";
            btn_Number_3.Size = new System.Drawing.Size(87, 83);
            btn_Number_3.TabIndex = 6;
            btn_Number_3.Text = "button4";
            btn_Number_3.UseVisualStyleBackColor = true;
            btn_Number_3.Click += btn_Number_3_Click;
            // 
            // btn_Number_4
            // 
            btn_Number_4.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_4.Location = new System.Drawing.Point(384, 434);
            btn_Number_4.Name = "btn_Number_4";
            btn_Number_4.Size = new System.Drawing.Size(87, 83);
            btn_Number_4.TabIndex = 7;
            btn_Number_4.Text = "button5";
            btn_Number_4.UseVisualStyleBackColor = true;
            btn_Number_4.Click += btn_Number_4_Click;
            // 
            // btn_Number_9
            // 
            btn_Number_9.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_9.Location = new System.Drawing.Point(384, 523);
            btn_Number_9.Name = "btn_Number_9";
            btn_Number_9.Size = new System.Drawing.Size(87, 83);
            btn_Number_9.TabIndex = 12;
            btn_Number_9.Text = "button6";
            btn_Number_9.UseVisualStyleBackColor = true;
            btn_Number_9.Click += btn_Number_9_Click;
            // 
            // btn_Number_8
            // 
            btn_Number_8.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_8.Location = new System.Drawing.Point(291, 523);
            btn_Number_8.Name = "btn_Number_8";
            btn_Number_8.Size = new System.Drawing.Size(87, 83);
            btn_Number_8.TabIndex = 11;
            btn_Number_8.Text = "button7";
            btn_Number_8.UseVisualStyleBackColor = true;
            btn_Number_8.Click += btn_Number_8_Click;
            // 
            // btn_Number_7
            // 
            btn_Number_7.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_7.Location = new System.Drawing.Point(198, 523);
            btn_Number_7.Name = "btn_Number_7";
            btn_Number_7.Size = new System.Drawing.Size(87, 83);
            btn_Number_7.TabIndex = 10;
            btn_Number_7.Text = "button8";
            btn_Number_7.UseVisualStyleBackColor = true;
            btn_Number_7.Click += btn_Number_7_Click;
            // 
            // btn_Number_6
            // 
            btn_Number_6.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_6.Location = new System.Drawing.Point(105, 523);
            btn_Number_6.Name = "btn_Number_6";
            btn_Number_6.Size = new System.Drawing.Size(87, 83);
            btn_Number_6.TabIndex = 9;
            btn_Number_6.Text = "button9";
            btn_Number_6.UseVisualStyleBackColor = true;
            btn_Number_6.Click += btn_Number_6_Click;
            // 
            // btn_Number_5
            // 
            btn_Number_5.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_5.Location = new System.Drawing.Point(12, 523);
            btn_Number_5.Name = "btn_Number_5";
            btn_Number_5.Size = new System.Drawing.Size(87, 83);
            btn_Number_5.TabIndex = 8;
            btn_Number_5.Text = "button10";
            btn_Number_5.UseVisualStyleBackColor = true;
            btn_Number_5.Click += btn_Number_5_Click;
            // 
            // btn_Equal
            // 
            btn_Equal.BackColor = System.Drawing.Color.RoyalBlue;
            btn_Equal.FlatAppearance.BorderSize = 0;
            btn_Equal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Equal.Font = new System.Drawing.Font("맑은 고딕", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btn_Equal.Location = new System.Drawing.Point(264, 311);
            btn_Equal.Name = "btn_Equal";
            btn_Equal.Size = new System.Drawing.Size(87, 83);
            btn_Equal.TabIndex = 14;
            btn_Equal.Text = "=";
            btn_Equal.UseVisualStyleBackColor = false;
            btn_Equal.Click += btn_Equal_Click;
            btn_Equal.KeyDown += btn_Equal_KeyDown;
            btn_Equal.KeyPress += btn_Equal_KeyPress;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("맑은 고딕", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(115, 314);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(63, 65);
            label3.TabIndex = 15;
            label3.Text = "+";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_x
            // 
            lb_x.AutoSize = true;
            lb_x.Font = new System.Drawing.Font("돋움", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lb_x.Location = new System.Drawing.Point(50, 328);
            lb_x.Name = "lb_x";
            lb_x.Size = new System.Drawing.Size(49, 48);
            lb_x.TabIndex = 17;
            lb_x.Text = "-";
            lb_x.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_y
            // 
            lb_y.AutoSize = true;
            lb_y.Font = new System.Drawing.Font("돋움", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lb_y.Location = new System.Drawing.Point(198, 327);
            lb_y.Name = "lb_y";
            lb_y.Size = new System.Drawing.Size(49, 48);
            lb_y.TabIndex = 18;
            lb_y.Text = "-";
            lb_y.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("맑은 고딕", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(325, 314);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(161, 65);
            label1.TabIndex = 20;
            label1.Text = "Result";
            // 
            // labelProgressBar1
            // 
            labelProgressBar1.CustomText = "";
            labelProgressBar1.Location = new System.Drawing.Point(12, 12);
            labelProgressBar1.Maximum = 200;
            labelProgressBar1.Name = "labelProgressBar1";
            labelProgressBar1.ProgressColor = System.Drawing.Color.LightGreen;
            labelProgressBar1.Size = new System.Drawing.Size(459, 29);
            labelProgressBar1.TabIndex = 22;
            labelProgressBar1.TextColor = System.Drawing.Color.RoyalBlue;
            labelProgressBar1.TextFont = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            labelProgressBar1.Value = 200;
            labelProgressBar1.VisualMode = ProgressBarDisplayMode.CustomText;
            // 
            // timer2
            // 
            timer2.Interval = 750;
            timer2.Tick += timer2_Tick;
            // 
            // lb_Sec
            // 
            lb_Sec.AutoSize = true;
            lb_Sec.Font = new System.Drawing.Font("맑은 고딕", 63.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lb_Sec.ForeColor = System.Drawing.Color.Transparent;
            lb_Sec.Location = new System.Drawing.Point(188, 152);
            lb_Sec.Name = "lb_Sec";
            lb_Sec.Size = new System.Drawing.Size(97, 113);
            lb_Sec.TabIndex = 23;
            lb_Sec.Text = "0";
            // 
            // btn_Plus_ok
            // 
            btn_Plus_ok.BackColor = System.Drawing.Color.White;
            btn_Plus_ok.Enabled = false;
            btn_Plus_ok.Font = new System.Drawing.Font("휴먼둥근헤드라인", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btn_Plus_ok.ForeColor = System.Drawing.Color.Black;
            btn_Plus_ok.Location = new System.Drawing.Point(160, 335);
            btn_Plus_ok.Name = "btn_Plus_ok";
            btn_Plus_ok.Size = new System.Drawing.Size(164, 87);
            btn_Plus_ok.TabIndex = 25;
            btn_Plus_ok.Text = "확인";
            btn_Plus_ok.UseVisualStyleBackColor = false;
            btn_Plus_ok.Visible = false;
            btn_Plus_ok.Click += btn_Plus_ok_Click;
            // 
            // lb_Plus_lastscore
            // 
            lb_Plus_lastscore.AutoSize = true;
            lb_Plus_lastscore.Enabled = false;
            lb_Plus_lastscore.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Plus_lastscore.ForeColor = System.Drawing.Color.White;
            lb_Plus_lastscore.Location = new System.Drawing.Point(60, 170);
            lb_Plus_lastscore.Name = "lb_Plus_lastscore";
            lb_Plus_lastscore.Size = new System.Drawing.Size(369, 74);
            lb_Plus_lastscore.TabIndex = 26;
            lb_Plus_lastscore.Text = "score : 200";
            lb_Plus_lastscore.Visible = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.ForeColor = System.Drawing.Color.White;
            label4.Location = new System.Drawing.Point(113, 163);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(256, 19);
            label4.TabIndex = 27;
            label4.Text = "답 입력 후 A를 눌러주세요";
            // 
            // Plus
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.RoyalBlue;
            ClientSize = new System.Drawing.Size(484, 661);
            Controls.Add(label4);
            Controls.Add(lb_Plus_lastscore);
            Controls.Add(btn_Plus_ok);
            Controls.Add(lb_Sec);
            Controls.Add(labelProgressBar1);
            Controls.Add(label1);
            Controls.Add(lb_y);
            Controls.Add(lb_x);
            Controls.Add(label3);
            Controls.Add(btn_Equal);
            Controls.Add(btn_Number_9);
            Controls.Add(btn_Number_8);
            Controls.Add(btn_Number_7);
            Controls.Add(btn_Number_6);
            Controls.Add(btn_Number_5);
            Controls.Add(btn_Number_4);
            Controls.Add(btn_Number_3);
            Controls.Add(btn_Number_2);
            Controls.Add(btn_Number_1);
            Controls.Add(btn_Number_0);
            Controls.Add(label2);
            Controls.Add(lb_Score);
            Name = "Plus";
            Text = "더하기를 하자 게임";
            KeyDown += Form1_KeyDown;
            KeyPress += Form1_KeyPress;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lb_Score;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Number_0;
        private System.Windows.Forms.Button btn_Number_1;
        private System.Windows.Forms.Button btn_Number_2;
        private System.Windows.Forms.Button btn_Number_3;
        private System.Windows.Forms.Button btn_Number_4;
        private System.Windows.Forms.Button btn_Number_9;
        private System.Windows.Forms.Button btn_Number_8;
        private System.Windows.Forms.Button btn_Number_7;
        private System.Windows.Forms.Button btn_Number_6;
        private System.Windows.Forms.Button btn_Number_5;
        private System.Windows.Forms.Button btn_Equal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_x;
        private System.Windows.Forms.Label lb_y;
        // private LabelProgressBar progressBar1;
        private System.Windows.Forms.Label label1;
        private LabelProgressBar labelProgressBar1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lb_Sec;
        private System.Windows.Forms.Button btn_Plus_ok;
        private System.Windows.Forms.Label lb_Plus_lastscore;
        private System.Windows.Forms.Label label4;
    }
}
