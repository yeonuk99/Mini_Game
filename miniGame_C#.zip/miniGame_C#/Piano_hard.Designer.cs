﻿namespace Moble
{
    partial class Piano_hard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Piano_hard));
            lb_Score = new System.Windows.Forms.Label();
            timer1 = new System.Windows.Forms.Timer(components);
            label2 = new System.Windows.Forms.Label();
            btn_Do = new System.Windows.Forms.Button();
            btn_Re = new System.Windows.Forms.Button();
            btn_Mi = new System.Windows.Forms.Button();
            btn_Pa = new System.Windows.Forms.Button();
            btn_Sol = new System.Windows.Forms.Button();
            textBox1 = new System.Windows.Forms.TextBox();
            textBox2 = new System.Windows.Forms.TextBox();
            textBox3 = new System.Windows.Forms.TextBox();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            pictureBox3 = new System.Windows.Forms.PictureBox();
            pictureBox4 = new System.Windows.Forms.PictureBox();
            pictureBox5 = new System.Windows.Forms.PictureBox();
            pictureBox6 = new System.Windows.Forms.PictureBox();
            pictureBox7 = new System.Windows.Forms.PictureBox();
            pictureBox8 = new System.Windows.Forms.PictureBox();
            pictureBox9 = new System.Windows.Forms.PictureBox();
            pictureBox10 = new System.Windows.Forms.PictureBox();
            pictureBox11 = new System.Windows.Forms.PictureBox();
            pictureBox12 = new System.Windows.Forms.PictureBox();
            pictureBox13 = new System.Windows.Forms.PictureBox();
            pictureBox14 = new System.Windows.Forms.PictureBox();
            pictureBox15 = new System.Windows.Forms.PictureBox();
            pictureBox16 = new System.Windows.Forms.PictureBox();
            pictureBox17 = new System.Windows.Forms.PictureBox();
            pictureBox18 = new System.Windows.Forms.PictureBox();
            pictureBox19 = new System.Windows.Forms.PictureBox();
            pictureBox20 = new System.Windows.Forms.PictureBox();
            pictureBox21 = new System.Windows.Forms.PictureBox();
            pictureBox22 = new System.Windows.Forms.PictureBox();
            pictureBox23 = new System.Windows.Forms.PictureBox();
            pictureBox24 = new System.Windows.Forms.PictureBox();
            imageList1 = new System.Windows.Forms.ImageList(components);
            labelProgressBar_Piano2 = new LabelProgressBar();
            lb_Start = new System.Windows.Forms.Label();
            timer2 = new System.Windows.Forms.Timer(components);
            imageList2 = new System.Windows.Forms.ImageList(components);
            pictureBox25 = new System.Windows.Forms.PictureBox();
            pictureBox26 = new System.Windows.Forms.PictureBox();
            pictureBox27 = new System.Windows.Forms.PictureBox();
            pictureBox28 = new System.Windows.Forms.PictureBox();
            pictureBox29 = new System.Windows.Forms.PictureBox();
            pictureBox30 = new System.Windows.Forms.PictureBox();
            btn_Ra = new System.Windows.Forms.Button();
            textBox4 = new System.Windows.Forms.TextBox();
            btn_Pianohard_ok = new System.Windows.Forms.Button();
            lb_Pianohard_lastscore = new System.Windows.Forms.Label();
            lb_space = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).BeginInit();
            SuspendLayout();
            // 
            // lb_Score
            // 
            lb_Score.AutoSize = true;
            lb_Score.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Score.ForeColor = System.Drawing.Color.White;
            lb_Score.Location = new System.Drawing.Point(175, 35);
            lb_Score.Name = "lb_Score";
            lb_Score.Size = new System.Drawing.Size(70, 74);
            lb_Score.TabIndex = 0;
            lb_Score.Text = "0";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.Color.White;
            label2.Location = new System.Drawing.Point(225, 100);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(52, 19);
            label2.TabIndex = 2;
            label2.Text = "score";
            // 
            // btn_Do
            // 
            btn_Do.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Do.ForeColor = System.Drawing.Color.DarkGray;
            btn_Do.Location = new System.Drawing.Point(16, 549);
            btn_Do.Name = "btn_Do";
            btn_Do.Size = new System.Drawing.Size(70, 100);
            btn_Do.TabIndex = 3;
            btn_Do.Text = "\r\n도A\r\n";
            btn_Do.UseVisualStyleBackColor = true;
            // 
            // btn_Re
            // 
            btn_Re.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Re.ForeColor = System.Drawing.Color.DarkGray;
            btn_Re.Location = new System.Drawing.Point(94, 549);
            btn_Re.Name = "btn_Re";
            btn_Re.Size = new System.Drawing.Size(70, 100);
            btn_Re.TabIndex = 4;
            btn_Re.Text = "\r\n레S\r\n";
            btn_Re.UseVisualStyleBackColor = true;
            // 
            // btn_Mi
            // 
            btn_Mi.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Mi.ForeColor = System.Drawing.Color.DarkGray;
            btn_Mi.Location = new System.Drawing.Point(172, 549);
            btn_Mi.Name = "btn_Mi";
            btn_Mi.Size = new System.Drawing.Size(70, 100);
            btn_Mi.TabIndex = 5;
            btn_Mi.Text = "\r\n미D";
            btn_Mi.UseVisualStyleBackColor = true;
            // 
            // btn_Pa
            // 
            btn_Pa.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Pa.ForeColor = System.Drawing.Color.DarkGray;
            btn_Pa.Location = new System.Drawing.Point(250, 549);
            btn_Pa.Name = "btn_Pa";
            btn_Pa.Size = new System.Drawing.Size(70, 100);
            btn_Pa.TabIndex = 6;
            btn_Pa.Text = "\r\n파J";
            btn_Pa.UseVisualStyleBackColor = true;
            // 
            // btn_Sol
            // 
            btn_Sol.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Sol.ForeColor = System.Drawing.Color.DarkGray;
            btn_Sol.Location = new System.Drawing.Point(327, 549);
            btn_Sol.Name = "btn_Sol";
            btn_Sol.Size = new System.Drawing.Size(70, 100);
            btn_Sol.TabIndex = 7;
            btn_Sol.Text = "\r\n솔K";
            btn_Sol.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.BackColor = System.Drawing.Color.Black;
            textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            textBox1.Enabled = false;
            textBox1.Location = new System.Drawing.Point(54, 538);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new System.Drawing.Size(70, 35);
            textBox1.TabIndex = 8;
            // 
            // textBox2
            // 
            textBox2.BackColor = System.Drawing.Color.Black;
            textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            textBox2.Enabled = false;
            textBox2.Location = new System.Drawing.Point(132, 538);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new System.Drawing.Size(70, 35);
            textBox2.TabIndex = 9;
            // 
            // textBox3
            // 
            textBox3.BackColor = System.Drawing.Color.Black;
            textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            textBox3.Enabled = false;
            textBox3.Location = new System.Drawing.Point(288, 538);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new System.Drawing.Size(70, 35);
            textBox3.TabIndex = 10;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new System.Drawing.Point(32, 140);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(70, 70);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (System.Drawing.Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new System.Drawing.Point(101, 140);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(70, 70);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex = 13;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (System.Drawing.Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new System.Drawing.Point(170, 140);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new System.Drawing.Size(70, 70);
            pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox3.TabIndex = 14;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (System.Drawing.Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new System.Drawing.Point(239, 140);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new System.Drawing.Size(70, 70);
            pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox4.TabIndex = 15;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (System.Drawing.Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new System.Drawing.Point(308, 140);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new System.Drawing.Size(70, 70);
            pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox5.TabIndex = 16;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (System.Drawing.Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new System.Drawing.Point(377, 140);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new System.Drawing.Size(70, 70);
            pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 17;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (System.Drawing.Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new System.Drawing.Point(32, 220);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new System.Drawing.Size(70, 70);
            pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox7.TabIndex = 18;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (System.Drawing.Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new System.Drawing.Point(101, 220);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new System.Drawing.Size(70, 70);
            pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox8.TabIndex = 19;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (System.Drawing.Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new System.Drawing.Point(170, 220);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new System.Drawing.Size(70, 70);
            pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox9.TabIndex = 20;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (System.Drawing.Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new System.Drawing.Point(239, 220);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new System.Drawing.Size(70, 70);
            pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 21;
            pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (System.Drawing.Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new System.Drawing.Point(308, 220);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new System.Drawing.Size(70, 70);
            pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 22;
            pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (System.Drawing.Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new System.Drawing.Point(377, 220);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new System.Drawing.Size(70, 70);
            pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox12.TabIndex = 23;
            pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (System.Drawing.Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new System.Drawing.Point(32, 300);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new System.Drawing.Size(70, 70);
            pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox13.TabIndex = 24;
            pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (System.Drawing.Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new System.Drawing.Point(101, 300);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new System.Drawing.Size(70, 70);
            pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox14.TabIndex = 25;
            pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            pictureBox15.Image = (System.Drawing.Image)resources.GetObject("pictureBox15.Image");
            pictureBox15.Location = new System.Drawing.Point(170, 300);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new System.Drawing.Size(70, 70);
            pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox15.TabIndex = 26;
            pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            pictureBox16.Image = (System.Drawing.Image)resources.GetObject("pictureBox16.Image");
            pictureBox16.Location = new System.Drawing.Point(239, 300);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new System.Drawing.Size(70, 70);
            pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox16.TabIndex = 27;
            pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            pictureBox17.Image = (System.Drawing.Image)resources.GetObject("pictureBox17.Image");
            pictureBox17.Location = new System.Drawing.Point(308, 300);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new System.Drawing.Size(70, 70);
            pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox17.TabIndex = 28;
            pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            pictureBox18.Image = (System.Drawing.Image)resources.GetObject("pictureBox18.Image");
            pictureBox18.Location = new System.Drawing.Point(377, 300);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new System.Drawing.Size(70, 70);
            pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox18.TabIndex = 29;
            pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            pictureBox19.Image = (System.Drawing.Image)resources.GetObject("pictureBox19.Image");
            pictureBox19.Location = new System.Drawing.Point(32, 380);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new System.Drawing.Size(70, 70);
            pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox19.TabIndex = 30;
            pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            pictureBox20.Image = (System.Drawing.Image)resources.GetObject("pictureBox20.Image");
            pictureBox20.Location = new System.Drawing.Point(101, 380);
            pictureBox20.Name = "pictureBox20";
            pictureBox20.Size = new System.Drawing.Size(70, 70);
            pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox20.TabIndex = 31;
            pictureBox20.TabStop = false;
            // 
            // pictureBox21
            // 
            pictureBox21.Image = (System.Drawing.Image)resources.GetObject("pictureBox21.Image");
            pictureBox21.Location = new System.Drawing.Point(170, 380);
            pictureBox21.Name = "pictureBox21";
            pictureBox21.Size = new System.Drawing.Size(70, 70);
            pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox21.TabIndex = 32;
            pictureBox21.TabStop = false;
            // 
            // pictureBox22
            // 
            pictureBox22.Image = (System.Drawing.Image)resources.GetObject("pictureBox22.Image");
            pictureBox22.Location = new System.Drawing.Point(239, 380);
            pictureBox22.Name = "pictureBox22";
            pictureBox22.Size = new System.Drawing.Size(70, 70);
            pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox22.TabIndex = 33;
            pictureBox22.TabStop = false;
            // 
            // pictureBox23
            // 
            pictureBox23.Image = (System.Drawing.Image)resources.GetObject("pictureBox23.Image");
            pictureBox23.Location = new System.Drawing.Point(308, 380);
            pictureBox23.Name = "pictureBox23";
            pictureBox23.Size = new System.Drawing.Size(70, 70);
            pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox23.TabIndex = 34;
            pictureBox23.TabStop = false;
            // 
            // pictureBox24
            // 
            pictureBox24.Image = (System.Drawing.Image)resources.GetObject("pictureBox24.Image");
            pictureBox24.Location = new System.Drawing.Point(377, 380);
            pictureBox24.Name = "pictureBox24";
            pictureBox24.Size = new System.Drawing.Size(70, 70);
            pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox24.TabIndex = 35;
            pictureBox24.TabStop = false;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
            imageList1.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = System.Drawing.Color.Transparent;
            imageList1.Images.SetKeyName(0, "도1.png");
            imageList1.Images.SetKeyName(1, "레1.png");
            imageList1.Images.SetKeyName(2, "미1.png");
            imageList1.Images.SetKeyName(3, "파1.png");
            imageList1.Images.SetKeyName(4, "솔1.png");
            imageList1.Images.SetKeyName(5, "라1.png");
            // 
            // labelProgressBar_Piano2
            // 
            labelProgressBar_Piano2.BackColor = System.Drawing.Color.RoyalBlue;
            labelProgressBar_Piano2.CustomText = "";
            labelProgressBar_Piano2.Location = new System.Drawing.Point(12, 12);
            labelProgressBar_Piano2.Maximum = 200;
            labelProgressBar_Piano2.Name = "labelProgressBar_Piano2";
            labelProgressBar_Piano2.ProgressColor = System.Drawing.Color.LightGreen;
            labelProgressBar_Piano2.Size = new System.Drawing.Size(460, 30);
            labelProgressBar_Piano2.TabIndex = 37;
            labelProgressBar_Piano2.TextColor = System.Drawing.Color.RoyalBlue;
            labelProgressBar_Piano2.TextFont = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            labelProgressBar_Piano2.Value = 200;
            labelProgressBar_Piano2.VisualMode = ProgressBarDisplayMode.CustomText;
            // 
            // lb_Start
            // 
            lb_Start.AutoSize = true;
            lb_Start.Enabled = false;
            lb_Start.Font = new System.Drawing.Font("맑은 고딕", 129.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lb_Start.Location = new System.Drawing.Point(12, 148);
            lb_Start.Name = "lb_Start";
            lb_Start.Size = new System.Drawing.Size(197, 229);
            lb_Start.TabIndex = 38;
            lb_Start.Text = "3";
            // 
            // timer2
            // 
            timer2.Interval = 1000;
            timer2.Tick += timer2_Tick;
            // 
            // imageList2
            // 
            imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
            imageList2.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imageList2.ImageStream");
            imageList2.TransparentColor = System.Drawing.Color.Transparent;
            imageList2.Images.SetKeyName(0, "도2.png");
            imageList2.Images.SetKeyName(1, "레2.png");
            imageList2.Images.SetKeyName(2, "미2.png");
            imageList2.Images.SetKeyName(3, "파2.png");
            imageList2.Images.SetKeyName(4, "솔2.png");
            imageList2.Images.SetKeyName(5, "라2.png");
            // 
            // pictureBox25
            // 
            pictureBox25.Image = (System.Drawing.Image)resources.GetObject("pictureBox25.Image");
            pictureBox25.Location = new System.Drawing.Point(32, 461);
            pictureBox25.Name = "pictureBox25";
            pictureBox25.Size = new System.Drawing.Size(70, 70);
            pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox25.TabIndex = 39;
            pictureBox25.TabStop = false;
            // 
            // pictureBox26
            // 
            pictureBox26.Image = (System.Drawing.Image)resources.GetObject("pictureBox26.Image");
            pictureBox26.Location = new System.Drawing.Point(101, 461);
            pictureBox26.Name = "pictureBox26";
            pictureBox26.Size = new System.Drawing.Size(70, 70);
            pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox26.TabIndex = 40;
            pictureBox26.TabStop = false;
            // 
            // pictureBox27
            // 
            pictureBox27.Image = (System.Drawing.Image)resources.GetObject("pictureBox27.Image");
            pictureBox27.Location = new System.Drawing.Point(170, 461);
            pictureBox27.Name = "pictureBox27";
            pictureBox27.Size = new System.Drawing.Size(70, 70);
            pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox27.TabIndex = 41;
            pictureBox27.TabStop = false;
            // 
            // pictureBox28
            // 
            pictureBox28.Image = (System.Drawing.Image)resources.GetObject("pictureBox28.Image");
            pictureBox28.Location = new System.Drawing.Point(239, 461);
            pictureBox28.Name = "pictureBox28";
            pictureBox28.Size = new System.Drawing.Size(70, 70);
            pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox28.TabIndex = 42;
            pictureBox28.TabStop = false;
            // 
            // pictureBox29
            // 
            pictureBox29.Image = (System.Drawing.Image)resources.GetObject("pictureBox29.Image");
            pictureBox29.Location = new System.Drawing.Point(308, 461);
            pictureBox29.Name = "pictureBox29";
            pictureBox29.Size = new System.Drawing.Size(70, 70);
            pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox29.TabIndex = 43;
            pictureBox29.TabStop = false;
            // 
            // pictureBox30
            // 
            pictureBox30.Image = (System.Drawing.Image)resources.GetObject("pictureBox30.Image");
            pictureBox30.Location = new System.Drawing.Point(377, 461);
            pictureBox30.Name = "pictureBox30";
            pictureBox30.Size = new System.Drawing.Size(70, 70);
            pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            pictureBox30.TabIndex = 44;
            pictureBox30.TabStop = false;
            // 
            // btn_Ra
            // 
            btn_Ra.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Ra.ForeColor = System.Drawing.Color.DarkGray;
            btn_Ra.Location = new System.Drawing.Point(405, 549);
            btn_Ra.Name = "btn_Ra";
            btn_Ra.Size = new System.Drawing.Size(70, 100);
            btn_Ra.TabIndex = 45;
            btn_Ra.Text = "\r\n라L";
            btn_Ra.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            textBox4.BackColor = System.Drawing.Color.Black;
            textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            textBox4.Enabled = false;
            textBox4.Location = new System.Drawing.Point(365, 537);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new System.Drawing.Size(70, 35);
            textBox4.TabIndex = 46;
            // 
            // btn_Pianohard_ok
            // 
            btn_Pianohard_ok.BackColor = System.Drawing.Color.White;
            btn_Pianohard_ok.Enabled = false;
            btn_Pianohard_ok.Font = new System.Drawing.Font("휴먼둥근헤드라인", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Pianohard_ok.ForeColor = System.Drawing.Color.Black;
            btn_Pianohard_ok.Location = new System.Drawing.Point(160, 335);
            btn_Pianohard_ok.Name = "btn_Pianohard_ok";
            btn_Pianohard_ok.Size = new System.Drawing.Size(164, 87);
            btn_Pianohard_ok.TabIndex = 47;
            btn_Pianohard_ok.Text = "확인";
            btn_Pianohard_ok.UseVisualStyleBackColor = false;
            btn_Pianohard_ok.Visible = false;
            btn_Pianohard_ok.Click += btn_Pianohard_ok_Click;
            // 
            // lb_Pianohard_lastscore
            // 
            lb_Pianohard_lastscore.AutoSize = true;
            lb_Pianohard_lastscore.Enabled = false;
            lb_Pianohard_lastscore.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Pianohard_lastscore.ForeColor = System.Drawing.Color.White;
            lb_Pianohard_lastscore.Location = new System.Drawing.Point(60, 170);
            lb_Pianohard_lastscore.Name = "lb_Pianohard_lastscore";
            lb_Pianohard_lastscore.Size = new System.Drawing.Size(369, 74);
            lb_Pianohard_lastscore.TabIndex = 48;
            lb_Pianohard_lastscore.Text = "score : 200";
            lb_Pianohard_lastscore.Visible = false;
            // 
            // lb_space
            // 
            lb_space.AutoSize = true;
            lb_space.Font = new System.Drawing.Font("맑은 고딕", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_space.Location = new System.Drawing.Point(41, 390);
            lb_space.Name = "lb_space";
            lb_space.Size = new System.Drawing.Size(394, 128);
            lb_space.TabIndex = 49;
            lb_space.Text = "          ";
            // 
            // Piano_hard
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.RoyalBlue;
            ClientSize = new System.Drawing.Size(484, 661);
            Controls.Add(btn_Pianohard_ok);
            Controls.Add(lb_space);
            Controls.Add(lb_Pianohard_lastscore);
            Controls.Add(textBox4);
            Controls.Add(btn_Ra);
            Controls.Add(pictureBox30);
            Controls.Add(pictureBox29);
            Controls.Add(pictureBox28);
            Controls.Add(pictureBox27);
            Controls.Add(pictureBox26);
            Controls.Add(pictureBox25);
            Controls.Add(lb_Start);
            Controls.Add(labelProgressBar_Piano2);
            Controls.Add(pictureBox24);
            Controls.Add(pictureBox23);
            Controls.Add(pictureBox22);
            Controls.Add(pictureBox21);
            Controls.Add(pictureBox20);
            Controls.Add(pictureBox19);
            Controls.Add(pictureBox18);
            Controls.Add(pictureBox17);
            Controls.Add(pictureBox16);
            Controls.Add(pictureBox15);
            Controls.Add(pictureBox14);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(btn_Sol);
            Controls.Add(btn_Pa);
            Controls.Add(btn_Mi);
            Controls.Add(btn_Re);
            Controls.Add(btn_Do);
            Controls.Add(label2);
            Controls.Add(lb_Score);
            Name = "Piano_hard";
            Text = "피아노 게임 하드모드";
            KeyDown += Piano2_KeyDown;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lb_Score;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Do;
        private System.Windows.Forms.Button btn_Re;
        private System.Windows.Forms.Button btn_Mi;
        private System.Windows.Forms.Button btn_Pa;
        private System.Windows.Forms.Button btn_Sol;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.ImageList imageList1;
        private LabelProgressBar labelProgressBar_Piano2;
        private System.Windows.Forms.Label lb_Start;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.Button btn_Ra;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button btn_Pianohard_ok;
        private System.Windows.Forms.Label lb_Pianohard_lastscore;
        private System.Windows.Forms.Label lb_space;
    }
}
