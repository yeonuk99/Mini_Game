﻿namespace Moble
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            timer1 = new System.Windows.Forms.Timer(components);
            tabControl1 = new System.Windows.Forms.TabControl();
            tP_Rank = new System.Windows.Forms.TabPage();
            label4 = new System.Windows.Forms.Label();
            lb_total_score = new System.Windows.Forms.Label();
            textBox1 = new System.Windows.Forms.TextBox();
            button1 = new System.Windows.Forms.Button();
            lb_R3_score = new System.Windows.Forms.Label();
            lb_R2_score = new System.Windows.Forms.Label();
            lb_R1_score = new System.Windows.Forms.Label();
            pictureBox4 = new System.Windows.Forms.PictureBox();
            pictureBox3 = new System.Windows.Forms.PictureBox();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            circularButton1 = new CircularButton();
            lb_Rank3 = new System.Windows.Forms.Label();
            lb_Rank2 = new System.Windows.Forms.Label();
            lb_Rank1 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            tP_Game = new System.Windows.Forms.TabPage();
            lb_GaLike = new System.Windows.Forms.Label();
            btn_GaLike = new System.Windows.Forms.Button();
            imageList2 = new System.Windows.Forms.ImageList(components);
            btn_Ga = new System.Windows.Forms.Button();
            lb_PiLike = new System.Windows.Forms.Label();
            lb_JaLike = new System.Windows.Forms.Label();
            btn_JaLike = new System.Windows.Forms.Button();
            btn_Ja = new System.Windows.Forms.Button();
            lb_BuLike = new System.Windows.Forms.Label();
            btn_BuLike = new System.Windows.Forms.Button();
            lb_BangLike = new System.Windows.Forms.Label();
            btn_BangLike = new System.Windows.Forms.Button();
            lb_SameLike = new System.Windows.Forms.Label();
            btn_SameLike = new System.Windows.Forms.Button();
            lb_JoaLike = new System.Windows.Forms.Label();
            btn_JoaLike = new System.Windows.Forms.Button();
            lb_SoonLike = new System.Windows.Forms.Label();
            lb_TheLike = new System.Windows.Forms.Label();
            btn_TheLike = new System.Windows.Forms.Button();
            btn_Pi = new System.Windows.Forms.Button();
            btn_Bu = new System.Windows.Forms.Button();
            btn_Joa = new System.Windows.Forms.Button();
            btn_Bang = new System.Windows.Forms.Button();
            btn_Same = new System.Windows.Forms.Button();
            btn_Soon = new System.Windows.Forms.Button();
            btn_The = new System.Windows.Forms.Button();
            btn_PiLike = new System.Windows.Forms.Button();
            btn_SoonLike = new System.Windows.Forms.Button();
            tP_Hard = new System.Windows.Forms.TabPage();
            label27 = new System.Windows.Forms.Label();
            label26 = new System.Windows.Forms.Label();
            label25 = new System.Windows.Forms.Label();
            label24 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            lb_bangH = new System.Windows.Forms.Label();
            btn_bangHLike = new System.Windows.Forms.Button();
            lb_sameH = new System.Windows.Forms.Label();
            btn_SameHLike = new System.Windows.Forms.Button();
            lb_JuaH = new System.Windows.Forms.Label();
            btn_juaHLike = new System.Windows.Forms.Button();
            lb_CalH = new System.Windows.Forms.Label();
            btn_CalHLike = new System.Windows.Forms.Button();
            btn_pi_h = new System.Windows.Forms.Button();
            lb_PiH = new System.Windows.Forms.Label();
            btn_PHLike = new System.Windows.Forms.Button();
            btn_left_h = new System.Windows.Forms.Button();
            btn_arr_h = new System.Windows.Forms.Button();
            btn_same_h = new System.Windows.Forms.Button();
            btn_pl_h = new System.Windows.Forms.Button();
            tabControl1.SuspendLayout();
            tP_Rank.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tP_Game.SuspendLayout();
            tP_Hard.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tP_Rank);
            tabControl1.Controls.Add(tP_Game);
            tabControl1.Controls.Add(tP_Hard);
            tabControl1.Location = new System.Drawing.Point(30, 2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new System.Drawing.Size(420, 647);
            tabControl1.TabIndex = 3;
            // 
            // tP_Rank
            // 
            tP_Rank.BackColor = System.Drawing.Color.RoyalBlue;
            tP_Rank.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            tP_Rank.Controls.Add(label4);
            tP_Rank.Controls.Add(lb_total_score);
            tP_Rank.Controls.Add(textBox1);
            tP_Rank.Controls.Add(button1);
            tP_Rank.Controls.Add(lb_R3_score);
            tP_Rank.Controls.Add(lb_R2_score);
            tP_Rank.Controls.Add(lb_R1_score);
            tP_Rank.Controls.Add(pictureBox4);
            tP_Rank.Controls.Add(pictureBox3);
            tP_Rank.Controls.Add(pictureBox2);
            tP_Rank.Controls.Add(pictureBox1);
            tP_Rank.Controls.Add(circularButton1);
            tP_Rank.Controls.Add(lb_Rank3);
            tP_Rank.Controls.Add(lb_Rank2);
            tP_Rank.Controls.Add(lb_Rank1);
            tP_Rank.Controls.Add(label3);
            tP_Rank.Controls.Add(label2);
            tP_Rank.Controls.Add(label1);
            tP_Rank.ForeColor = System.Drawing.Color.RoyalBlue;
            tP_Rank.Location = new System.Drawing.Point(4, 24);
            tP_Rank.Name = "tP_Rank";
            tP_Rank.Padding = new System.Windows.Forms.Padding(3);
            tP_Rank.Size = new System.Drawing.Size(412, 619);
            tP_Rank.TabIndex = 0;
            tP_Rank.Text = "명예의 전당";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.ForeColor = System.Drawing.Color.White;
            label4.Location = new System.Drawing.Point(16, 561);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(65, 19);
            label4.TabIndex = 19;
            label4.Text = "score : ";
            // 
            // lb_total_score
            // 
            lb_total_score.AutoSize = true;
            lb_total_score.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lb_total_score.ForeColor = System.Drawing.Color.White;
            lb_total_score.Location = new System.Drawing.Point(87, 559);
            lb_total_score.Name = "lb_total_score";
            lb_total_score.Size = new System.Drawing.Size(17, 21);
            lb_total_score.TabIndex = 18;
            lb_total_score.Text = "-";
            // 
            // textBox1
            // 
            textBox1.Location = new System.Drawing.Point(87, 522);
            textBox1.Name = "textBox1";
            textBox1.Size = new System.Drawing.Size(193, 23);
            textBox1.TabIndex = 17;
            // 
            // button1
            // 
            button1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button1.ForeColor = System.Drawing.Color.Black;
            button1.Location = new System.Drawing.Point(304, 520);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(72, 29);
            button1.TabIndex = 16;
            button1.Text = "등록";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // lb_R3_score
            // 
            lb_R3_score.AutoSize = true;
            lb_R3_score.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_R3_score.ForeColor = System.Drawing.Color.White;
            lb_R3_score.Location = new System.Drawing.Point(253, 421);
            lb_R3_score.Name = "lb_R3_score";
            lb_R3_score.Size = new System.Drawing.Size(25, 30);
            lb_R3_score.TabIndex = 15;
            lb_R3_score.Text = "0";
            // 
            // lb_R2_score
            // 
            lb_R2_score.AutoSize = true;
            lb_R2_score.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_R2_score.ForeColor = System.Drawing.Color.White;
            lb_R2_score.Location = new System.Drawing.Point(253, 336);
            lb_R2_score.Name = "lb_R2_score";
            lb_R2_score.Size = new System.Drawing.Size(25, 30);
            lb_R2_score.TabIndex = 14;
            lb_R2_score.Text = "0";
            // 
            // lb_R1_score
            // 
            lb_R1_score.AutoSize = true;
            lb_R1_score.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_R1_score.ForeColor = System.Drawing.Color.White;
            lb_R1_score.Location = new System.Drawing.Point(253, 250);
            lb_R1_score.Name = "lb_R1_score";
            lb_R1_score.Size = new System.Drawing.Size(25, 30);
            lb_R1_score.TabIndex = 4;
            lb_R1_score.Text = "0";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (System.Drawing.Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new System.Drawing.Point(30, 404);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new System.Drawing.Size(74, 66);
            pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (System.Drawing.Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new System.Drawing.Point(30, 317);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new System.Drawing.Size(74, 66);
            pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (System.Drawing.Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new System.Drawing.Point(30, 230);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(74, 66);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new System.Drawing.Point(63, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(286, 214);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // circularButton1
            // 
            circularButton1.Location = new System.Drawing.Point(253, 265);
            circularButton1.Name = "circularButton1";
            circularButton1.Size = new System.Drawing.Size(0, 0);
            circularButton1.TabIndex = 4;
            circularButton1.Text = "circularButton1";
            circularButton1.UseVisualStyleBackColor = true;
            // 
            // lb_Rank3
            // 
            lb_Rank3.AutoSize = true;
            lb_Rank3.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Rank3.ForeColor = System.Drawing.Color.White;
            lb_Rank3.Location = new System.Drawing.Point(159, 421);
            lb_Rank3.Name = "lb_Rank3";
            lb_Rank3.Size = new System.Drawing.Size(22, 30);
            lb_Rank3.TabIndex = 7;
            lb_Rank3.Text = "-";
            // 
            // lb_Rank2
            // 
            lb_Rank2.AutoSize = true;
            lb_Rank2.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Rank2.ForeColor = System.Drawing.Color.White;
            lb_Rank2.Location = new System.Drawing.Point(159, 336);
            lb_Rank2.Name = "lb_Rank2";
            lb_Rank2.Size = new System.Drawing.Size(22, 30);
            lb_Rank2.TabIndex = 6;
            lb_Rank2.Text = "-";
            // 
            // lb_Rank1
            // 
            lb_Rank1.AutoSize = true;
            lb_Rank1.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Rank1.ForeColor = System.Drawing.Color.White;
            lb_Rank1.Location = new System.Drawing.Point(159, 250);
            lb_Rank1.Name = "lb_Rank1";
            lb_Rank1.Size = new System.Drawing.Size(22, 30);
            lb_Rank1.TabIndex = 5;
            lb_Rank1.Text = "-";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.ForeColor = System.Drawing.Color.White;
            label3.Location = new System.Drawing.Point(119, 421);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(30, 30);
            label3.TabIndex = 2;
            label3.Text = "3.";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.Color.White;
            label2.Location = new System.Drawing.Point(119, 336);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(30, 30);
            label2.TabIndex = 1;
            label2.Text = "2.";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.White;
            label1.Location = new System.Drawing.Point(119, 250);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(30, 30);
            label1.TabIndex = 0;
            label1.Text = "1.";
            // 
            // tP_Game
            // 
            tP_Game.BackColor = System.Drawing.Color.RoyalBlue;
            tP_Game.Controls.Add(lb_GaLike);
            tP_Game.Controls.Add(btn_GaLike);
            tP_Game.Controls.Add(btn_Ga);
            tP_Game.Controls.Add(lb_PiLike);
            tP_Game.Controls.Add(lb_JaLike);
            tP_Game.Controls.Add(btn_JaLike);
            tP_Game.Controls.Add(btn_Ja);
            tP_Game.Controls.Add(lb_BuLike);
            tP_Game.Controls.Add(btn_BuLike);
            tP_Game.Controls.Add(lb_BangLike);
            tP_Game.Controls.Add(btn_BangLike);
            tP_Game.Controls.Add(lb_SameLike);
            tP_Game.Controls.Add(btn_SameLike);
            tP_Game.Controls.Add(lb_JoaLike);
            tP_Game.Controls.Add(btn_JoaLike);
            tP_Game.Controls.Add(lb_SoonLike);
            tP_Game.Controls.Add(lb_TheLike);
            tP_Game.Controls.Add(btn_TheLike);
            tP_Game.Controls.Add(btn_Pi);
            tP_Game.Controls.Add(btn_Bu);
            tP_Game.Controls.Add(btn_Joa);
            tP_Game.Controls.Add(btn_Bang);
            tP_Game.Controls.Add(btn_Same);
            tP_Game.Controls.Add(btn_Soon);
            tP_Game.Controls.Add(btn_The);
            tP_Game.Controls.Add(btn_PiLike);
            tP_Game.Controls.Add(btn_SoonLike);
            tP_Game.ForeColor = System.Drawing.Color.RoyalBlue;
            tP_Game.Location = new System.Drawing.Point(4, 24);
            tP_Game.Name = "tP_Game";
            tP_Game.Padding = new System.Windows.Forms.Padding(3);
            tP_Game.Size = new System.Drawing.Size(412, 619);
            tP_Game.TabIndex = 1;
            tP_Game.Text = "게임";
            // 
            // lb_GaLike
            // 
            lb_GaLike.AutoSize = true;
            lb_GaLike.BackColor = System.Drawing.Color.White;
            lb_GaLike.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_GaLike.ForeColor = System.Drawing.Color.Black;
            lb_GaLike.Location = new System.Drawing.Point(363, 504);
            lb_GaLike.Name = "lb_GaLike";
            lb_GaLike.Size = new System.Drawing.Size(15, 17);
            lb_GaLike.TabIndex = 42;
            lb_GaLike.Text = "0";
            // 
            // btn_GaLike
            // 
            btn_GaLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_GaLike.ImageIndex = 0;
            btn_GaLike.ImageList = imageList2;
            btn_GaLike.Location = new System.Drawing.Point(332, 466);
            btn_GaLike.Name = "btn_GaLike";
            btn_GaLike.Size = new System.Drawing.Size(74, 60);
            btn_GaLike.TabIndex = 41;
            btn_GaLike.UseVisualStyleBackColor = true;
            btn_GaLike.Click += btn_GaLike_Click;
            // 
            // imageList2
            // 
            imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            imageList2.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imageList2.ImageStream");
            imageList2.TransparentColor = System.Drawing.Color.Transparent;
            imageList2.Images.SetKeyName(0, "좋아요2.png");
            // 
            // btn_Ga
            // 
            btn_Ga.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Ga.Image = (System.Drawing.Image)resources.GetObject("btn_Ga.Image");
            btn_Ga.Location = new System.Drawing.Point(6, 466);
            btn_Ga.Name = "btn_Ga";
            btn_Ga.Size = new System.Drawing.Size(320, 60);
            btn_Ga.TabIndex = 40;
            btn_Ga.UseVisualStyleBackColor = true;
            btn_Ga.Click += btn_Ga_Click;
            // 
            // lb_PiLike
            // 
            lb_PiLike.AutoSize = true;
            lb_PiLike.BackColor = System.Drawing.Color.White;
            lb_PiLike.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_PiLike.ForeColor = System.Drawing.Color.Black;
            lb_PiLike.Location = new System.Drawing.Point(362, 44);
            lb_PiLike.Name = "lb_PiLike";
            lb_PiLike.Size = new System.Drawing.Size(15, 17);
            lb_PiLike.TabIndex = 9;
            lb_PiLike.Text = "0";
            // 
            // lb_JaLike
            // 
            lb_JaLike.AutoSize = true;
            lb_JaLike.BackColor = System.Drawing.Color.White;
            lb_JaLike.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_JaLike.ForeColor = System.Drawing.Color.Black;
            lb_JaLike.Location = new System.Drawing.Point(363, 570);
            lb_JaLike.Name = "lb_JaLike";
            lb_JaLike.Size = new System.Drawing.Size(15, 17);
            lb_JaLike.TabIndex = 37;
            lb_JaLike.Text = "0";
            // 
            // btn_JaLike
            // 
            btn_JaLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_JaLike.ImageIndex = 0;
            btn_JaLike.ImageList = imageList2;
            btn_JaLike.Location = new System.Drawing.Point(332, 532);
            btn_JaLike.Name = "btn_JaLike";
            btn_JaLike.Size = new System.Drawing.Size(74, 60);
            btn_JaLike.TabIndex = 36;
            btn_JaLike.UseVisualStyleBackColor = true;
            btn_JaLike.Click += btn_JaLike_Click;
            // 
            // btn_Ja
            // 
            btn_Ja.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Ja.Image = (System.Drawing.Image)resources.GetObject("btn_Ja.Image");
            btn_Ja.Location = new System.Drawing.Point(6, 532);
            btn_Ja.Name = "btn_Ja";
            btn_Ja.Size = new System.Drawing.Size(320, 60);
            btn_Ja.TabIndex = 35;
            btn_Ja.UseVisualStyleBackColor = true;
            btn_Ja.Click += btn_Ja_Click;
            // 
            // lb_BuLike
            // 
            lb_BuLike.AutoSize = true;
            lb_BuLike.BackColor = System.Drawing.Color.White;
            lb_BuLike.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_BuLike.ForeColor = System.Drawing.Color.Black;
            lb_BuLike.Location = new System.Drawing.Point(362, 438);
            lb_BuLike.Name = "lb_BuLike";
            lb_BuLike.Size = new System.Drawing.Size(15, 17);
            lb_BuLike.TabIndex = 34;
            lb_BuLike.Text = "0";
            // 
            // btn_BuLike
            // 
            btn_BuLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_BuLike.ImageIndex = 0;
            btn_BuLike.ImageList = imageList2;
            btn_BuLike.Location = new System.Drawing.Point(331, 400);
            btn_BuLike.Name = "btn_BuLike";
            btn_BuLike.Size = new System.Drawing.Size(74, 60);
            btn_BuLike.TabIndex = 33;
            btn_BuLike.UseVisualStyleBackColor = true;
            btn_BuLike.Click += btn_BuLike_Click;
            // 
            // lb_BangLike
            // 
            lb_BangLike.AutoSize = true;
            lb_BangLike.BackColor = System.Drawing.Color.White;
            lb_BangLike.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_BangLike.ForeColor = System.Drawing.Color.Black;
            lb_BangLike.Location = new System.Drawing.Point(362, 374);
            lb_BangLike.Name = "lb_BangLike";
            lb_BangLike.Size = new System.Drawing.Size(15, 17);
            lb_BangLike.TabIndex = 32;
            lb_BangLike.Text = "0";
            // 
            // btn_BangLike
            // 
            btn_BangLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_BangLike.ImageIndex = 0;
            btn_BangLike.ImageList = imageList2;
            btn_BangLike.Location = new System.Drawing.Point(331, 334);
            btn_BangLike.Name = "btn_BangLike";
            btn_BangLike.Size = new System.Drawing.Size(74, 60);
            btn_BangLike.TabIndex = 31;
            btn_BangLike.UseVisualStyleBackColor = true;
            btn_BangLike.Click += btn_BangLike_Click;
            // 
            // lb_SameLike
            // 
            lb_SameLike.AutoSize = true;
            lb_SameLike.BackColor = System.Drawing.Color.White;
            lb_SameLike.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_SameLike.ForeColor = System.Drawing.Color.Black;
            lb_SameLike.Location = new System.Drawing.Point(362, 308);
            lb_SameLike.Name = "lb_SameLike";
            lb_SameLike.Size = new System.Drawing.Size(15, 17);
            lb_SameLike.TabIndex = 30;
            lb_SameLike.Text = "0";
            // 
            // btn_SameLike
            // 
            btn_SameLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_SameLike.ImageIndex = 0;
            btn_SameLike.ImageList = imageList2;
            btn_SameLike.Location = new System.Drawing.Point(331, 270);
            btn_SameLike.Name = "btn_SameLike";
            btn_SameLike.Size = new System.Drawing.Size(74, 60);
            btn_SameLike.TabIndex = 29;
            btn_SameLike.UseVisualStyleBackColor = true;
            btn_SameLike.Click += btn_SameLike_Click;
            // 
            // lb_JoaLike
            // 
            lb_JoaLike.AutoSize = true;
            lb_JoaLike.BackColor = System.Drawing.Color.White;
            lb_JoaLike.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_JoaLike.ForeColor = System.Drawing.Color.Black;
            lb_JoaLike.Location = new System.Drawing.Point(362, 242);
            lb_JoaLike.Name = "lb_JoaLike";
            lb_JoaLike.Size = new System.Drawing.Size(15, 17);
            lb_JoaLike.TabIndex = 28;
            lb_JoaLike.Text = "0";
            // 
            // btn_JoaLike
            // 
            btn_JoaLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_JoaLike.ImageIndex = 0;
            btn_JoaLike.ImageList = imageList2;
            btn_JoaLike.Location = new System.Drawing.Point(331, 204);
            btn_JoaLike.Name = "btn_JoaLike";
            btn_JoaLike.Size = new System.Drawing.Size(74, 60);
            btn_JoaLike.TabIndex = 27;
            btn_JoaLike.UseVisualStyleBackColor = true;
            btn_JoaLike.Click += btn_JoaLike_Click;
            // 
            // lb_SoonLike
            // 
            lb_SoonLike.AutoSize = true;
            lb_SoonLike.BackColor = System.Drawing.Color.White;
            lb_SoonLike.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_SoonLike.ForeColor = System.Drawing.Color.Black;
            lb_SoonLike.Location = new System.Drawing.Point(362, 176);
            lb_SoonLike.Name = "lb_SoonLike";
            lb_SoonLike.Size = new System.Drawing.Size(15, 17);
            lb_SoonLike.TabIndex = 26;
            lb_SoonLike.Text = "0";
            // 
            // lb_TheLike
            // 
            lb_TheLike.AutoSize = true;
            lb_TheLike.BackColor = System.Drawing.Color.White;
            lb_TheLike.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_TheLike.ForeColor = System.Drawing.Color.Black;
            lb_TheLike.Location = new System.Drawing.Point(362, 110);
            lb_TheLike.Name = "lb_TheLike";
            lb_TheLike.Size = new System.Drawing.Size(15, 17);
            lb_TheLike.TabIndex = 24;
            lb_TheLike.Text = "0";
            // 
            // btn_TheLike
            // 
            btn_TheLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_TheLike.ImageIndex = 0;
            btn_TheLike.ImageList = imageList2;
            btn_TheLike.Location = new System.Drawing.Point(331, 72);
            btn_TheLike.Name = "btn_TheLike";
            btn_TheLike.Size = new System.Drawing.Size(74, 60);
            btn_TheLike.TabIndex = 23;
            btn_TheLike.UseVisualStyleBackColor = true;
            btn_TheLike.Click += btn_TheLike_Click;
            // 
            // btn_Pi
            // 
            btn_Pi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Pi.Image = (System.Drawing.Image)resources.GetObject("btn_Pi.Image");
            btn_Pi.Location = new System.Drawing.Point(6, 6);
            btn_Pi.Name = "btn_Pi";
            btn_Pi.Size = new System.Drawing.Size(320, 60);
            btn_Pi.TabIndex = 22;
            btn_Pi.UseVisualStyleBackColor = true;
            btn_Pi.Click += btn_Pi_Click;
            // 
            // btn_Bu
            // 
            btn_Bu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Bu.Image = (System.Drawing.Image)resources.GetObject("btn_Bu.Image");
            btn_Bu.Location = new System.Drawing.Point(6, 400);
            btn_Bu.Name = "btn_Bu";
            btn_Bu.Size = new System.Drawing.Size(320, 60);
            btn_Bu.TabIndex = 6;
            btn_Bu.UseVisualStyleBackColor = true;
            btn_Bu.Click += btn_Bu_Click;
            // 
            // btn_Joa
            // 
            btn_Joa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Joa.Image = (System.Drawing.Image)resources.GetObject("btn_Joa.Image");
            btn_Joa.Location = new System.Drawing.Point(5, 204);
            btn_Joa.Name = "btn_Joa";
            btn_Joa.Size = new System.Drawing.Size(320, 60);
            btn_Joa.TabIndex = 5;
            btn_Joa.UseVisualStyleBackColor = true;
            btn_Joa.Click += btn_Joa_Click;
            // 
            // btn_Bang
            // 
            btn_Bang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Bang.Image = (System.Drawing.Image)resources.GetObject("btn_Bang.Image");
            btn_Bang.Location = new System.Drawing.Point(6, 334);
            btn_Bang.Name = "btn_Bang";
            btn_Bang.Size = new System.Drawing.Size(320, 60);
            btn_Bang.TabIndex = 4;
            btn_Bang.UseVisualStyleBackColor = true;
            btn_Bang.Click += btn_Bang_Click;
            // 
            // btn_Same
            // 
            btn_Same.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Same.Image = (System.Drawing.Image)resources.GetObject("btn_Same.Image");
            btn_Same.Location = new System.Drawing.Point(6, 270);
            btn_Same.Name = "btn_Same";
            btn_Same.Size = new System.Drawing.Size(320, 60);
            btn_Same.TabIndex = 3;
            btn_Same.UseVisualStyleBackColor = true;
            btn_Same.Click += btn_Same_Click;
            // 
            // btn_Soon
            // 
            btn_Soon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Soon.Image = (System.Drawing.Image)resources.GetObject("btn_Soon.Image");
            btn_Soon.Location = new System.Drawing.Point(5, 138);
            btn_Soon.Name = "btn_Soon";
            btn_Soon.Size = new System.Drawing.Size(320, 60);
            btn_Soon.TabIndex = 2;
            btn_Soon.UseVisualStyleBackColor = true;
            btn_Soon.Click += btn_Soon_Click;
            // 
            // btn_The
            // 
            btn_The.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_The.Image = (System.Drawing.Image)resources.GetObject("btn_The.Image");
            btn_The.Location = new System.Drawing.Point(6, 72);
            btn_The.Name = "btn_The";
            btn_The.Size = new System.Drawing.Size(320, 60);
            btn_The.TabIndex = 1;
            btn_The.UseVisualStyleBackColor = true;
            btn_The.Click += btn_The_Click;
            // 
            // btn_PiLike
            // 
            btn_PiLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_PiLike.ImageIndex = 0;
            btn_PiLike.ImageList = imageList2;
            btn_PiLike.Location = new System.Drawing.Point(331, 6);
            btn_PiLike.Name = "btn_PiLike";
            btn_PiLike.Size = new System.Drawing.Size(74, 60);
            btn_PiLike.TabIndex = 38;
            btn_PiLike.UseVisualStyleBackColor = true;
            btn_PiLike.Click += btn_PiLike_Click;
            // 
            // btn_SoonLike
            // 
            btn_SoonLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_SoonLike.ImageIndex = 0;
            btn_SoonLike.ImageList = imageList2;
            btn_SoonLike.Location = new System.Drawing.Point(331, 138);
            btn_SoonLike.Name = "btn_SoonLike";
            btn_SoonLike.Size = new System.Drawing.Size(74, 60);
            btn_SoonLike.TabIndex = 39;
            btn_SoonLike.UseVisualStyleBackColor = true;
            btn_SoonLike.Click += btn_SoonLike_Click;
            // 
            // tP_Hard
            // 
            tP_Hard.BackColor = System.Drawing.Color.RoyalBlue;
            tP_Hard.Controls.Add(label27);
            tP_Hard.Controls.Add(label26);
            tP_Hard.Controls.Add(label25);
            tP_Hard.Controls.Add(label24);
            tP_Hard.Controls.Add(label15);
            tP_Hard.Controls.Add(lb_bangH);
            tP_Hard.Controls.Add(btn_bangHLike);
            tP_Hard.Controls.Add(lb_sameH);
            tP_Hard.Controls.Add(btn_SameHLike);
            tP_Hard.Controls.Add(lb_JuaH);
            tP_Hard.Controls.Add(btn_juaHLike);
            tP_Hard.Controls.Add(lb_CalH);
            tP_Hard.Controls.Add(btn_CalHLike);
            tP_Hard.Controls.Add(btn_pi_h);
            tP_Hard.Controls.Add(lb_PiH);
            tP_Hard.Controls.Add(btn_PHLike);
            tP_Hard.Controls.Add(btn_left_h);
            tP_Hard.Controls.Add(btn_arr_h);
            tP_Hard.Controls.Add(btn_same_h);
            tP_Hard.Controls.Add(btn_pl_h);
            tP_Hard.Location = new System.Drawing.Point(4, 24);
            tP_Hard.Name = "tP_Hard";
            tP_Hard.Size = new System.Drawing.Size(412, 619);
            tP_Hard.TabIndex = 2;
            tP_Hard.Text = "하드모드";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.BackColor = System.Drawing.Color.White;
            label27.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label27.ForeColor = System.Drawing.Color.Red;
            label27.Location = new System.Drawing.Point(266, 307);
            label27.Name = "label27";
            label27.Size = new System.Drawing.Size(59, 21);
            label27.TabIndex = 68;
            label27.Text = "HARD";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.BackColor = System.Drawing.Color.White;
            label26.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label26.ForeColor = System.Drawing.Color.Red;
            label26.Location = new System.Drawing.Point(266, 243);
            label26.Name = "label26";
            label26.Size = new System.Drawing.Size(59, 21);
            label26.TabIndex = 67;
            label26.Text = "HARD";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.BackColor = System.Drawing.Color.White;
            label25.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label25.ForeColor = System.Drawing.Color.Red;
            label25.Location = new System.Drawing.Point(265, 177);
            label25.Name = "label25";
            label25.Size = new System.Drawing.Size(59, 21);
            label25.TabIndex = 66;
            label25.Text = "HARD";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.BackColor = System.Drawing.Color.White;
            label24.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label24.ForeColor = System.Drawing.Color.Red;
            label24.Location = new System.Drawing.Point(266, 44);
            label24.Name = "label24";
            label24.Size = new System.Drawing.Size(59, 21);
            label24.TabIndex = 64;
            label24.Text = "HARD";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = System.Drawing.Color.White;
            label15.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label15.ForeColor = System.Drawing.Color.Red;
            label15.Location = new System.Drawing.Point(265, 109);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(59, 21);
            label15.TabIndex = 63;
            label15.Text = "HARD";
            // 
            // lb_bangH
            // 
            lb_bangH.AutoSize = true;
            lb_bangH.BackColor = System.Drawing.Color.White;
            lb_bangH.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_bangH.ForeColor = System.Drawing.Color.Black;
            lb_bangH.Location = new System.Drawing.Point(362, 309);
            lb_bangH.Name = "lb_bangH";
            lb_bangH.Size = new System.Drawing.Size(15, 17);
            lb_bangH.TabIndex = 57;
            lb_bangH.Text = "0";
            // 
            // btn_bangHLike
            // 
            btn_bangHLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_bangHLike.ImageIndex = 0;
            btn_bangHLike.ImageList = imageList2;
            btn_bangHLike.Location = new System.Drawing.Point(331, 269);
            btn_bangHLike.Name = "btn_bangHLike";
            btn_bangHLike.Size = new System.Drawing.Size(74, 60);
            btn_bangHLike.TabIndex = 56;
            btn_bangHLike.UseVisualStyleBackColor = true;
            btn_bangHLike.Click += btn_BangHLike_Click;
            // 
            // lb_sameH
            // 
            lb_sameH.AutoSize = true;
            lb_sameH.BackColor = System.Drawing.Color.White;
            lb_sameH.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_sameH.ForeColor = System.Drawing.Color.Black;
            lb_sameH.Location = new System.Drawing.Point(362, 243);
            lb_sameH.Name = "lb_sameH";
            lb_sameH.Size = new System.Drawing.Size(15, 17);
            lb_sameH.TabIndex = 55;
            lb_sameH.Text = "0";
            // 
            // btn_SameHLike
            // 
            btn_SameHLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_SameHLike.ImageIndex = 0;
            btn_SameHLike.ImageList = imageList2;
            btn_SameHLike.Location = new System.Drawing.Point(331, 205);
            btn_SameHLike.Name = "btn_SameHLike";
            btn_SameHLike.Size = new System.Drawing.Size(74, 60);
            btn_SameHLike.TabIndex = 54;
            btn_SameHLike.UseVisualStyleBackColor = true;
            btn_SameHLike.Click += btn_SameHLike_Click;
            // 
            // lb_JuaH
            // 
            lb_JuaH.AutoSize = true;
            lb_JuaH.BackColor = System.Drawing.Color.White;
            lb_JuaH.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_JuaH.ForeColor = System.Drawing.Color.Black;
            lb_JuaH.Location = new System.Drawing.Point(362, 177);
            lb_JuaH.Name = "lb_JuaH";
            lb_JuaH.Size = new System.Drawing.Size(15, 17);
            lb_JuaH.TabIndex = 53;
            lb_JuaH.Text = "0";
            // 
            // btn_juaHLike
            // 
            btn_juaHLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_juaHLike.ImageIndex = 0;
            btn_juaHLike.ImageList = imageList2;
            btn_juaHLike.Location = new System.Drawing.Point(331, 139);
            btn_juaHLike.Name = "btn_juaHLike";
            btn_juaHLike.Size = new System.Drawing.Size(74, 60);
            btn_juaHLike.TabIndex = 52;
            btn_juaHLike.UseVisualStyleBackColor = true;
            btn_juaHLike.Click += btn_JauHLike_Click;
            // 
            // lb_CalH
            // 
            lb_CalH.AutoSize = true;
            lb_CalH.BackColor = System.Drawing.Color.White;
            lb_CalH.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_CalH.ForeColor = System.Drawing.Color.Black;
            lb_CalH.Location = new System.Drawing.Point(362, 110);
            lb_CalH.Name = "lb_CalH";
            lb_CalH.Size = new System.Drawing.Size(15, 17);
            lb_CalH.TabIndex = 49;
            lb_CalH.Text = "0";
            // 
            // btn_CalHLike
            // 
            btn_CalHLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_CalHLike.ImageIndex = 0;
            btn_CalHLike.ImageList = imageList2;
            btn_CalHLike.Location = new System.Drawing.Point(331, 72);
            btn_CalHLike.Name = "btn_CalHLike";
            btn_CalHLike.Size = new System.Drawing.Size(74, 60);
            btn_CalHLike.TabIndex = 48;
            btn_CalHLike.UseVisualStyleBackColor = true;
            btn_CalHLike.Click += btn_CalHLike_Click;
            // 
            // btn_pi_h
            // 
            btn_pi_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_pi_h.ForeColor = System.Drawing.Color.RoyalBlue;
            btn_pi_h.Image = (System.Drawing.Image)resources.GetObject("btn_pi_h.Image");
            btn_pi_h.Location = new System.Drawing.Point(6, 6);
            btn_pi_h.Name = "btn_pi_h";
            btn_pi_h.Size = new System.Drawing.Size(320, 60);
            btn_pi_h.TabIndex = 47;
            btn_pi_h.UseVisualStyleBackColor = true;
            btn_pi_h.Click += btn_pi_h_Click;
            // 
            // lb_PiH
            // 
            lb_PiH.AutoSize = true;
            lb_PiH.BackColor = System.Drawing.Color.White;
            lb_PiH.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_PiH.ForeColor = System.Drawing.Color.Black;
            lb_PiH.Location = new System.Drawing.Point(362, 44);
            lb_PiH.Name = "lb_PiH";
            lb_PiH.Size = new System.Drawing.Size(15, 17);
            lb_PiH.TabIndex = 46;
            lb_PiH.Text = "0";
            // 
            // btn_PHLike
            // 
            btn_PHLike.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_PHLike.ImageIndex = 0;
            btn_PHLike.ImageList = imageList2;
            btn_PHLike.Location = new System.Drawing.Point(331, 6);
            btn_PHLike.Name = "btn_PHLike";
            btn_PHLike.Size = new System.Drawing.Size(74, 60);
            btn_PHLike.TabIndex = 45;
            btn_PHLike.UseVisualStyleBackColor = true;
            btn_PHLike.Click += btn_PHLike_Click;
            // 
            // btn_left_h
            // 
            btn_left_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_left_h.ForeColor = System.Drawing.Color.RoyalBlue;
            btn_left_h.Image = (System.Drawing.Image)resources.GetObject("btn_left_h.Image");
            btn_left_h.Location = new System.Drawing.Point(5, 139);
            btn_left_h.Name = "btn_left_h";
            btn_left_h.Size = new System.Drawing.Size(320, 60);
            btn_left_h.TabIndex = 43;
            btn_left_h.UseVisualStyleBackColor = true;
            btn_left_h.Click += btn_left_h_Click;
            // 
            // btn_arr_h
            // 
            btn_arr_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_arr_h.ForeColor = System.Drawing.Color.RoyalBlue;
            btn_arr_h.Image = (System.Drawing.Image)resources.GetObject("btn_arr_h.Image");
            btn_arr_h.Location = new System.Drawing.Point(6, 269);
            btn_arr_h.Name = "btn_arr_h";
            btn_arr_h.Size = new System.Drawing.Size(320, 60);
            btn_arr_h.TabIndex = 42;
            btn_arr_h.UseVisualStyleBackColor = true;
            btn_arr_h.Click += btn_arr_h_Click;
            // 
            // btn_same_h
            // 
            btn_same_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_same_h.ForeColor = System.Drawing.Color.RoyalBlue;
            btn_same_h.Image = (System.Drawing.Image)resources.GetObject("btn_same_h.Image");
            btn_same_h.Location = new System.Drawing.Point(6, 205);
            btn_same_h.Name = "btn_same_h";
            btn_same_h.Size = new System.Drawing.Size(320, 60);
            btn_same_h.TabIndex = 41;
            btn_same_h.UseVisualStyleBackColor = true;
            btn_same_h.Click += btn_same_h_Click;
            // 
            // btn_pl_h
            // 
            btn_pl_h.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_pl_h.ForeColor = System.Drawing.Color.RoyalBlue;
            btn_pl_h.Image = (System.Drawing.Image)resources.GetObject("btn_pl_h.Image");
            btn_pl_h.Location = new System.Drawing.Point(6, 72);
            btn_pl_h.Name = "btn_pl_h";
            btn_pl_h.Size = new System.Drawing.Size(320, 60);
            btn_pl_h.TabIndex = 39;
            btn_pl_h.UseVisualStyleBackColor = true;
            btn_pl_h.Click += btn_pl_h_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.RoyalBlue;
            ClientSize = new System.Drawing.Size(484, 661);
            Controls.Add(tabControl1);
            Name = "Main";
            Text = "메인 화면";
            tabControl1.ResumeLayout(false);
            tP_Rank.ResumeLayout(false);
            tP_Rank.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tP_Game.ResumeLayout(false);
            tP_Game.PerformLayout();
            tP_Hard.ResumeLayout(false);
            tP_Hard.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tP_Game;
        private System.Windows.Forms.TabPage tP_Rank;
        private CircularButton circularButton1;
        private System.Windows.Forms.Label lb_Rank3;
        private System.Windows.Forms.Label lb_Rank2;
        private System.Windows.Forms.Label lb_Rank1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Bang;
        private System.Windows.Forms.Button btn_Same;
        private System.Windows.Forms.Button btn_Soon;
        private System.Windows.Forms.Button btn_The;
        private System.Windows.Forms.Button btn_Joa;
        private System.Windows.Forms.TabPage tP_Hard;
        private System.Windows.Forms.Button btn_Bu;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lb_PiLike;
        private System.Windows.Forms.Button btn_Plike;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.Button btn_Pi;
        private System.Windows.Forms.Label lb_BuLike;
        private System.Windows.Forms.Button btn_BuLike;
        private System.Windows.Forms.Label lb_BangLike;
        private System.Windows.Forms.Button btn_BangLike;
        private System.Windows.Forms.Label lb_SameLike;
        private System.Windows.Forms.Button btn_SameLike;
        private System.Windows.Forms.Label lb_JoaLike;
        private System.Windows.Forms.Button btn_JoaLike;
        private System.Windows.Forms.Label lb_SoonLike;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label lb_TheLike;
        private System.Windows.Forms.Button btn_TheLike;
        private System.Windows.Forms.Label lb_JaLike;
        private System.Windows.Forms.Button btn_JaLike;
        private System.Windows.Forms.Button btn_Ja;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lb_bangH;
        private System.Windows.Forms.Button btn_bangHLike;
        private System.Windows.Forms.Label lb_sameH;
        private System.Windows.Forms.Button btn_SameHLike;
        private System.Windows.Forms.Label lb_JuaH;
        private System.Windows.Forms.Button btn_juaHLike;
        private System.Windows.Forms.Label lb_CalH;
        private System.Windows.Forms.Button btn_CalHLike;
        private System.Windows.Forms.Button btn_pi_h;
        private System.Windows.Forms.Label lb_PiH;
        private System.Windows.Forms.Button btn_PHLike;
        private System.Windows.Forms.Button btn_left_h;
        private System.Windows.Forms.Button btn_arr_h;
        private System.Windows.Forms.Button btn_same_h;
        private System.Windows.Forms.Button btn_pl_h;
        private System.Windows.Forms.Button btn_PiLike;
        private System.Windows.Forms.Button btn_SoonLike;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lb_GaLike;
        private System.Windows.Forms.Button btn_GaLike;
        private System.Windows.Forms.Button btn_Ga;
        private System.Windows.Forms.Label lb_R1_score;
        private System.Windows.Forms.Label lb_R3_score;
        private System.Windows.Forms.Label lb_R2_score;
        private System.Windows.Forms.Label lb_total_score;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
    }
}
