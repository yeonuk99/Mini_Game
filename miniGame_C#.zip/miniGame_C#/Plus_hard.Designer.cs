﻿namespace Moble
{
    partial class Plus_hard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new System.Windows.Forms.Label();
            timer1 = new System.Windows.Forms.Timer(components);
            label2 = new System.Windows.Forms.Label();
            btn_Number_0 = new System.Windows.Forms.Button();
            btn_Number_1 = new System.Windows.Forms.Button();
            btn_Number_2 = new System.Windows.Forms.Button();
            btn_Number_3 = new System.Windows.Forms.Button();
            btn_Number_4 = new System.Windows.Forms.Button();
            btn_Number_9 = new System.Windows.Forms.Button();
            btn_Number_8 = new System.Windows.Forms.Button();
            btn_Number_7 = new System.Windows.Forms.Button();
            btn_Number_6 = new System.Windows.Forms.Button();
            btn_Number_5 = new System.Windows.Forms.Button();
            lb_x = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            lb_y = new System.Windows.Forms.Label();
            btn_Result = new System.Windows.Forms.Button();
            lb_Result = new System.Windows.Forms.Label();
            button1 = new System.Windows.Forms.Button();
            labelProgressBar1 = new LabelProgressBar();
            timer2 = new System.Windows.Forms.Timer(components);
            lb_Sec = new System.Windows.Forms.Label();
            lb_Plushard_lastscore = new System.Windows.Forms.Label();
            btn_Plushard_ok = new System.Windows.Forms.Button();
            label4 = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.White;
            label1.Location = new System.Drawing.Point(175, 35);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(146, 74);
            label1.TabIndex = 0;
            label1.Text = "200";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.Color.White;
            label2.Location = new System.Drawing.Point(225, 100);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(52, 19);
            label2.TabIndex = 2;
            label2.Text = "score";
            // 
            // btn_Number_0
            // 
            btn_Number_0.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_0.Location = new System.Drawing.Point(9, 432);
            btn_Number_0.Name = "btn_Number_0";
            btn_Number_0.Size = new System.Drawing.Size(87, 83);
            btn_Number_0.TabIndex = 3;
            btn_Number_0.Text = "btn_Number_0";
            btn_Number_0.UseVisualStyleBackColor = true;
            btn_Number_0.Click += btn_Number_0_Click;
            // 
            // btn_Number_1
            // 
            btn_Number_1.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_1.Location = new System.Drawing.Point(101, 432);
            btn_Number_1.Name = "btn_Number_1";
            btn_Number_1.Size = new System.Drawing.Size(87, 83);
            btn_Number_1.TabIndex = 4;
            btn_Number_1.Text = "btn_Number_1\r\n";
            btn_Number_1.UseVisualStyleBackColor = true;
            btn_Number_1.Click += btn_Number_1_Click;
            // 
            // btn_Number_2
            // 
            btn_Number_2.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_2.Location = new System.Drawing.Point(194, 432);
            btn_Number_2.Name = "btn_Number_2";
            btn_Number_2.Size = new System.Drawing.Size(87, 83);
            btn_Number_2.TabIndex = 5;
            btn_Number_2.Text = "btn_Number_2";
            btn_Number_2.UseVisualStyleBackColor = true;
            btn_Number_2.Click += btn_Number_2_Click;
            // 
            // btn_Number_3
            // 
            btn_Number_3.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_3.Location = new System.Drawing.Point(287, 432);
            btn_Number_3.Name = "btn_Number_3";
            btn_Number_3.Size = new System.Drawing.Size(87, 83);
            btn_Number_3.TabIndex = 6;
            btn_Number_3.Text = "btn_Number_3";
            btn_Number_3.UseVisualStyleBackColor = true;
            btn_Number_3.Click += btn_Number_3_Click;
            // 
            // btn_Number_4
            // 
            btn_Number_4.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_4.Location = new System.Drawing.Point(380, 432);
            btn_Number_4.Name = "btn_Number_4";
            btn_Number_4.Size = new System.Drawing.Size(87, 83);
            btn_Number_4.TabIndex = 7;
            btn_Number_4.Text = "btn_Number_4";
            btn_Number_4.UseVisualStyleBackColor = true;
            btn_Number_4.Click += btn_Number_4_Click;
            // 
            // btn_Number_9
            // 
            btn_Number_9.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_9.Location = new System.Drawing.Point(380, 531);
            btn_Number_9.Name = "btn_Number_9";
            btn_Number_9.Size = new System.Drawing.Size(87, 83);
            btn_Number_9.TabIndex = 12;
            btn_Number_9.Text = "btn_Number_9";
            btn_Number_9.UseVisualStyleBackColor = true;
            btn_Number_9.Click += btn_Number_9_Click;
            // 
            // btn_Number_8
            // 
            btn_Number_8.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_8.Location = new System.Drawing.Point(287, 531);
            btn_Number_8.Name = "btn_Number_8";
            btn_Number_8.Size = new System.Drawing.Size(87, 83);
            btn_Number_8.TabIndex = 11;
            btn_Number_8.Text = "btn_Number_8";
            btn_Number_8.UseVisualStyleBackColor = true;
            btn_Number_8.Click += btn_Number_8_Click;
            // 
            // btn_Number_7
            // 
            btn_Number_7.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_7.Location = new System.Drawing.Point(194, 531);
            btn_Number_7.Name = "btn_Number_7";
            btn_Number_7.Size = new System.Drawing.Size(87, 83);
            btn_Number_7.TabIndex = 10;
            btn_Number_7.Text = "btn_Number_7";
            btn_Number_7.UseVisualStyleBackColor = true;
            btn_Number_7.Click += btn_Number_7_Click;
            // 
            // btn_Number_6
            // 
            btn_Number_6.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_6.Location = new System.Drawing.Point(101, 531);
            btn_Number_6.Name = "btn_Number_6";
            btn_Number_6.Size = new System.Drawing.Size(87, 83);
            btn_Number_6.TabIndex = 9;
            btn_Number_6.Text = "btn_Number_6";
            btn_Number_6.UseVisualStyleBackColor = true;
            btn_Number_6.Click += btn_Number_6_Click;
            // 
            // btn_Number_5
            // 
            btn_Number_5.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Number_5.Location = new System.Drawing.Point(9, 531);
            btn_Number_5.Name = "btn_Number_5";
            btn_Number_5.Size = new System.Drawing.Size(87, 83);
            btn_Number_5.TabIndex = 8;
            btn_Number_5.Text = "btn_Number_5";
            btn_Number_5.UseVisualStyleBackColor = true;
            btn_Number_5.Click += btn_Number_5_Click;
            // 
            // lb_x
            // 
            lb_x.AutoSize = true;
            lb_x.Font = new System.Drawing.Font("돋움", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lb_x.Location = new System.Drawing.Point(47, 343);
            lb_x.Name = "lb_x";
            lb_x.Size = new System.Drawing.Size(49, 48);
            lb_x.TabIndex = 13;
            lb_x.Text = "-";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("돋움", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(117, 343);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(49, 48);
            label3.TabIndex = 14;
            label3.Text = "-";
            // 
            // lb_y
            // 
            lb_y.AutoSize = true;
            lb_y.Font = new System.Drawing.Font("돋움", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lb_y.Location = new System.Drawing.Point(199, 343);
            lb_y.Name = "lb_y";
            lb_y.Size = new System.Drawing.Size(49, 48);
            lb_y.TabIndex = 15;
            lb_y.Text = "-";
            // 
            // btn_Result
            // 
            btn_Result.BackColor = System.Drawing.Color.RoyalBlue;
            btn_Result.FlatAppearance.BorderSize = 0;
            btn_Result.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn_Result.Font = new System.Drawing.Font("돋움", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_Result.Location = new System.Drawing.Point(274, 343);
            btn_Result.Name = "btn_Result";
            btn_Result.Size = new System.Drawing.Size(75, 64);
            btn_Result.TabIndex = 16;
            btn_Result.Text = "=";
            btn_Result.UseVisualStyleBackColor = false;
            btn_Result.Click += btn_Result_Click;
            // 
            // lb_Result
            // 
            lb_Result.AutoSize = true;
            lb_Result.Font = new System.Drawing.Font("맑은 고딕", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Result.Location = new System.Drawing.Point(311, 238);
            lb_Result.Name = "lb_Result";
            lb_Result.Size = new System.Drawing.Size(161, 65);
            lb_Result.TabIndex = 17;
            lb_Result.Text = "Result";
            // 
            // button1
            // 
            button1.Font = new System.Drawing.Font("맑은 고딕", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button1.Location = new System.Drawing.Point(380, 343);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(87, 83);
            button1.TabIndex = 18;
            button1.Text = "-";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // labelProgressBar1
            // 
            labelProgressBar1.CustomText = "";
            labelProgressBar1.Location = new System.Drawing.Point(12, 12);
            labelProgressBar1.Maximum = 200;
            labelProgressBar1.Name = "labelProgressBar1";
            labelProgressBar1.ProgressColor = System.Drawing.Color.LightGreen;
            labelProgressBar1.Size = new System.Drawing.Size(459, 29);
            labelProgressBar1.TabIndex = 19;
            labelProgressBar1.TextColor = System.Drawing.Color.RoyalBlue;
            labelProgressBar1.TextFont = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            labelProgressBar1.Value = 200;
            labelProgressBar1.VisualMode = ProgressBarDisplayMode.CustomText;
            // 
            // timer2
            // 
            timer2.Interval = 750;
            timer2.Tick += timer2_Tick;
            // 
            // lb_Sec
            // 
            lb_Sec.AutoSize = true;
            lb_Sec.Font = new System.Drawing.Font("맑은 고딕", 63.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lb_Sec.Location = new System.Drawing.Point(188, 152);
            lb_Sec.Name = "lb_Sec";
            lb_Sec.Size = new System.Drawing.Size(97, 113);
            lb_Sec.TabIndex = 20;
            lb_Sec.Text = "0";
            // 
            // lb_Plushard_lastscore
            // 
            lb_Plushard_lastscore.AutoSize = true;
            lb_Plushard_lastscore.Enabled = false;
            lb_Plushard_lastscore.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lb_Plushard_lastscore.ForeColor = System.Drawing.Color.White;
            lb_Plushard_lastscore.Location = new System.Drawing.Point(60, 185);
            lb_Plushard_lastscore.Name = "lb_Plushard_lastscore";
            lb_Plushard_lastscore.Size = new System.Drawing.Size(369, 74);
            lb_Plushard_lastscore.TabIndex = 25;
            lb_Plushard_lastscore.Text = "score : 200";
            lb_Plushard_lastscore.Visible = false;
            // 
            // btn_Plushard_ok
            // 
            btn_Plushard_ok.BackColor = System.Drawing.Color.White;
            btn_Plushard_ok.Enabled = false;
            btn_Plushard_ok.Font = new System.Drawing.Font("휴먼둥근헤드라인", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btn_Plushard_ok.ForeColor = System.Drawing.Color.Black;
            btn_Plushard_ok.Location = new System.Drawing.Point(160, 335);
            btn_Plushard_ok.Name = "btn_Plushard_ok";
            btn_Plushard_ok.Size = new System.Drawing.Size(164, 87);
            btn_Plushard_ok.TabIndex = 26;
            btn_Plushard_ok.Text = "확인";
            btn_Plushard_ok.UseVisualStyleBackColor = false;
            btn_Plushard_ok.Visible = false;
            btn_Plushard_ok.Click += btn_Plushard_ok_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.ForeColor = System.Drawing.Color.White;
            label4.Location = new System.Drawing.Point(123, 152);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(256, 19);
            label4.TabIndex = 27;
            label4.Text = "답 입력 후 A를 눌러주세요";
            // 
            // Plus_hard
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.RoyalBlue;
            ClientSize = new System.Drawing.Size(484, 661);
            Controls.Add(label4);
            Controls.Add(btn_Plushard_ok);
            Controls.Add(lb_Plushard_lastscore);
            Controls.Add(lb_Sec);
            Controls.Add(labelProgressBar1);
            Controls.Add(button1);
            Controls.Add(lb_Result);
            Controls.Add(lb_y);
            Controls.Add(label3);
            Controls.Add(lb_x);
            Controls.Add(btn_Number_9);
            Controls.Add(btn_Number_8);
            Controls.Add(btn_Number_7);
            Controls.Add(btn_Number_6);
            Controls.Add(btn_Number_5);
            Controls.Add(btn_Number_4);
            Controls.Add(btn_Number_3);
            Controls.Add(btn_Number_2);
            Controls.Add(btn_Number_1);
            Controls.Add(btn_Number_0);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btn_Result);
            Name = "Plus_hard";
            Text = "더하기를 하자 게임 하드모드";
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Number_0;
        private System.Windows.Forms.Button btn_Number_1;
        private System.Windows.Forms.Button btn_Number_2;
        private System.Windows.Forms.Button btn_Number_3;
        private System.Windows.Forms.Button btn_Number_4;
        private System.Windows.Forms.Button btn_Number_9;
        private System.Windows.Forms.Button btn_Number_8;
        private System.Windows.Forms.Button btn_Number_7;
        private System.Windows.Forms.Button btn_Number_6;
        private System.Windows.Forms.Button btn_Number_5;
        private System.Windows.Forms.Label lb_x;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_y;
        private System.Windows.Forms.Button btn_Result;
        private System.Windows.Forms.Label lb_Result;
        private System.Windows.Forms.Button button1;
        private LabelProgressBar labelProgressBar1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lb_Sec;
        private System.Windows.Forms.Label lb_Plushard_lastscore;
        private System.Windows.Forms.Button btn_Plushard_ok;
        private System.Windows.Forms.Label label4;
    }
}
